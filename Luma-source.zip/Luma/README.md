# Luma

Luma is a page-based workspace with an AI editor and the Codex companion.

This source snapshot includes page covers, stock photo search, dark mode, the compact AI menu, Puter and personal OpenAI provider support, page-scoped agent actions, and animated pet expressions and movement.

Source snapshot: b079dbde056593789c50d2c3822467b41bc4cdf7.

Runtime secrets, saved personal pages, account sessions, installed dependencies, and generated build output are excluded. Hosted authentication, database, file storage, and runtime secret configuration are supplied by the existing Sites deployment.
