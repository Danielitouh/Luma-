// Mirror textarea wrapping so the writing menu follows the caret, not the screen center.
export function textAnchor(element: HTMLTextAreaElement, position: number) {
  const style = getComputedStyle(element);
  const mirror = document.createElement('div');
  for (const property of ['fontFamily','fontSize','fontWeight','fontStyle','letterSpacing','lineHeight','paddingTop','paddingRight','paddingBottom','paddingLeft','borderTopWidth','borderRightWidth','borderBottomWidth','borderLeftWidth','boxSizing','textIndent','textTransform','wordSpacing','tabSize'] as const) mirror.style[property] = style[property];
  Object.assign(mirror.style, {position:'fixed',visibility:'hidden',pointerEvents:'none',left:'0',top:'0',width:element.getBoundingClientRect().width+'px',whiteSpace:'pre-wrap',overflowWrap:'break-word',borderStyle:'solid'});
  mirror.textContent = element.value.slice(0, position);
  const marker = document.createElement('span');
  marker.textContent = '\u200b';
  mirror.appendChild(marker);
  document.body.appendChild(mirror);
  const markerRect = marker.getBoundingClientRect();
  const mirrorRect = mirror.getBoundingClientRect();
  const left = markerRect.left - mirrorRect.left;
  const top = markerRect.top - mirrorRect.top;
  const height = parseFloat(style.lineHeight) || parseFloat(style.fontSize) * 1.5;
  mirror.remove();
  return {getBoundingClientRect: () => {
    const rect = element.getBoundingClientRect();
    return new DOMRect(rect.left + left - element.scrollLeft, rect.top + top - element.scrollTop, 1, height);
  }};
}
