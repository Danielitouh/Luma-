export type StockPhoto = {
  id: string;
  title: string;
  creator: string;
  url: string;
  thumbnail: string;
  source: string;
  license: string;
  licenseUrl: string;
};

type Metadata = Record<string, { value?: string }>;
type CommonsPage = {
  pageid: number;
  title: string;
  imageinfo?: Array<{
    width?: number;
    height?: number;
    mime?: string;
    thumburl?: string;
    descriptionurl?: string;
    extmetadata?: Metadata;
  }>;
};

function plainText(html: string) {
  const element = new DOMParser().parseFromString(html, 'text/html');
  return (element.body.textContent || '').replace(/\s+/g, ' ').trim();
}

export async function searchCommonsPhotos(query: string, signal: AbortSignal): Promise<StockPhoto[]> {
  const url = new URL('https://commons.wikimedia.org/w/api.php');
  for (const [key, value] of Object.entries({
    action: 'query', generator: 'search', gsrsearch: query.slice(0, 80),
    gsrnamespace: '6', gsrlimit: '50', prop: 'imageinfo',
    iiprop: 'url|size|mime|extmetadata', iiurlwidth: '1200',
    format: 'json', formatversion: '2', origin: '*',
  })) url.searchParams.set(key, value);

  const response = await fetch(url, { signal, credentials: 'omit' });
  if (!response.ok) throw new Error('Photo search is unavailable. Please try again.');
  const result = await response.json() as { query?: { pages?: CommonsPage[] }; error?: { info?: string } };
  if (result.error) throw new Error('Photo search is unavailable. Please try again.');

  return (result.query?.pages || []).flatMap(page => {
    const info = page.imageinfo?.[0];
    const metadata = info?.extmetadata;
    const license = plainText(metadata?.LicenseShortName?.value || '');
    const allowed = license === 'CC0' || /^public domain$/i.test(license) || /^CC BY(?:-SA)?(?: \d+(?:\.\d+)?)?$/i.test(license);
    const image = info?.thumburl;
    const source = info?.descriptionurl;
    const licenseUrl = (metadata?.LicenseUrl?.value || source)?.replace(/^http:\/\//, 'https://');
    if (!allowed || !info?.width || !info?.height || info.width < 900 || info.width / info.height < 1.3 ||
      !['image/jpeg', 'image/png', 'image/webp'].includes(info.mime || '') ||
      !image?.startsWith('https://') || !source?.startsWith('https://') || !licenseUrl?.startsWith('https://')) return [];

    return [{
      id: String(page.pageid), title: page.title.replace(/^File:/, '').replace(/\.[^.]+$/, '').replace(/_/g, ' ').slice(0, 200),
      creator: plainText(metadata?.Artist?.value || 'Unknown creator').slice(0, 150),
      url: image, thumbnail: image, source, license, licenseUrl,
    }];
  }).slice(0, 18);
}
