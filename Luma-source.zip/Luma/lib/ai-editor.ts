export type SpaceCandidate = {at: number; time: number; before: string};

export function doubleSpaceEdit(first: SpaceCandidate | null, text: string, start: number, end: number, now: number) {
  if (!first || now - first.time > 550 || start !== end || start !== first.at + 1) return null;
  if (text !== first.before.slice(0, first.at) + ' ' + first.before.slice(first.at)) return null;
  return {text: text.slice(0, first.at) + text.slice(first.at + 1), cursor: first.at};
}

export function insertGeneratedText(snapshot: {original: string; start: number; end: number; cursor: number; action: string}, generated: string) {
  const replaceSelection = snapshot.action === 'Rewrite' && snapshot.start !== snapshot.end;
  const from = replaceSelection ? snapshot.start : snapshot.cursor;
  const to = replaceSelection ? snapshot.end : snapshot.cursor;
  if (from < 0 || to < from || to > snapshot.original.length) throw new Error('The saved cursor is no longer valid.');
  return {text: snapshot.original.slice(0, from) + generated + snapshot.original.slice(to), cursor: from + generated.length};
}
