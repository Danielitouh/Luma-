import { createHash } from "node:crypto";
import { readdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

// A stable fingerprint of the files delivered to the workspace. Exclude the
// generated marker itself so two builds of the same source agree.
const roots = ["app", "components", "hooks", "lib", "public"];
const extraFiles = ["package.json", "pnpm-lock.yaml", "vite.config.ts"];
const marker = "public/luma-release.json";
const hash = createHash("sha256");

async function include(relative) {
  for (const entry of (await readdir(relative, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const child = path.posix.join(relative, entry.name);
    if (child === marker) continue;
    if (entry.isDirectory()) await include(child);
    else if (entry.isFile()) {
      hash.update(child);
      hash.update("\0");
      hash.update(await readFile(child));
      hash.update("\0");
    }
  }
}

for (const root of roots) await include(root);
for (const file of extraFiles) {
  hash.update(file);
  hash.update("\0");
  hash.update(await readFile(file));
  hash.update("\0");
}
await writeFile(marker, JSON.stringify({ schema: 1, version: hash.digest("hex") }) + "\n");
