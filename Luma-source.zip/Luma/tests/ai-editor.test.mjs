import assert from 'node:assert/strict';
import test from 'node:test';
import {doubleSpaceEdit, insertGeneratedText} from '../lib/ai-editor.ts';

test('rapid double space removes both spaces at the saved caret', () => {
  assert.deepEqual(doubleSpaceEdit({at: 4, before: 'Test', time: 100}, 'Test ', 5, 5, 320), {text: 'Test', cursor: 4});
  assert.deepEqual(doubleSpaceEdit({at: 0, before: '', time: 100}, ' ', 1, 1, 320), {text: '', cursor: 0});
  assert.deepEqual(doubleSpaceEdit({at: 3, before: 'one two', time: 100}, 'one  two', 4, 4, 320), {text: 'one two', cursor: 3});
});

test('slow typing, cursor moves, selection, or unrelated edits do not trigger', () => {
  const first = {at: 4, before: 'Test', time: 100};
  assert.equal(doubleSpaceEdit(first, 'Test ', 5, 5, 700), null);
  assert.equal(doubleSpaceEdit(first, 'Test ', 4, 4, 320), null);
  assert.equal(doubleSpaceEdit(first, 'Test ', 4, 5, 320), null);
  assert.equal(doubleSpaceEdit(first, 'Test x', 6, 6, 320), null);
});

test('continuation inserts exactly at the captured cursor without removing content', () => {
  assert.deepEqual(insertGeneratedText({original: 'Before after', start: 7, end: 7, cursor: 7, action: 'Continue text'}, 'NEW '), {text: 'Before NEW after', cursor: 11});
  assert.deepEqual(insertGeneratedText({original: '', start: 0, end: 0, cursor: 0, action: 'Continue text'}, 'Hello'), {text: 'Hello', cursor: 5});
});

test('only an original Rewrite command replaces selected text', () => {
  const target = {original: 'before selection after', start: 7, end: 16, cursor: 16};
  assert.deepEqual(insertGeneratedText({...target, action: 'Rewrite'}, 'revision'), {text: 'before revision after', cursor: 15});
  assert.deepEqual(insertGeneratedText({...target, action: 'Continue text'}, ' added'), {text: 'before selection added after', cursor: 22});
});
