import assert from 'node:assert/strict';
import test from 'node:test';
import {defaultSettings,settingsSchema} from '../lib/workspace.ts';

test('existing workspace settings receive a System theme without losing other choices',()=>{
  const {theme:_,...existing}=defaultSettings;
  const parsed=settingsSchema.parse({...existing,accent:'forest',density:'Compact'});
  assert.equal(parsed.theme,'system');
  assert.equal(parsed.accent,'forest');
  assert.equal(parsed.density,'Compact');
  assert.equal(settingsSchema.parse({...parsed,theme:'dark'}).theme,'dark');
});
