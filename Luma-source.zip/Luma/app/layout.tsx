import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Luma — Your workspace",
  description: "A little room to think. Pages, projects, and tasks in your personal workspace.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "Luma", statusBarStyle: "default" },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
    apple: "/apple-touch-icon.png",
  },
};

export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#e9edf0" };

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{__html:"try{const mode=localStorage.getItem('luma-theme')||'system';document.documentElement.dataset.lumaTheme=mode==='dark'||(mode==='system'&&matchMedia('(prefers-color-scheme: dark)').matches)?'dark':'light'}catch{}"}} /></head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
