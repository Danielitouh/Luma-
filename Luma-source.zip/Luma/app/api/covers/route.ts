import { env } from 'cloudflare:workers';
import { sameOrigin, userId } from '@/db/storage';

const MAX_SIZE = 8 * 1024 * 1024;
const signatures: Record<string, (bytes: Uint8Array) => boolean> = {
  'image/jpeg': b => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
  'image/png': b => b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 && b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a,
  'image/webp': b => String.fromCharCode(...b.slice(0, 4)) === 'RIFF' && String.fromCharCode(...b.slice(8, 12)) === 'WEBP',
  'image/gif': b => ['GIF87a', 'GIF89a'].includes(String.fromCharCode(...b.slice(0, 6))),
};

export async function POST(request: Request) {
  const user = userId(request);
  if (!user) return Response.json({ error: 'Sign in to add a picture.' }, { status: 401 });
  if (!sameOrigin(request)) return Response.json({ error: 'Invalid origin.' }, { status: 403 });
  const length = Number(request.headers.get('content-length'));
  if (length > MAX_SIZE + 100_000) return Response.json({ error: 'Choose a picture under 8 MB.' }, { status: 413 });
  try {
    const form = await request.formData();
    const file = form.get('image');
    if (!(file instanceof File) || !signatures[file.type] || file.size === 0 || file.size > MAX_SIZE)
      return Response.json({ error: 'Choose a JPG, PNG, WebP, or GIF under 8 MB.' }, { status: 400 });
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (!signatures[file.type](bytes)) return Response.json({ error: 'This file is not a valid picture.' }, { status: 400 });
    if (!env.BUCKET) throw new Error('Image storage unavailable');
    const cover = crypto.randomUUID();
    await env.BUCKET.put(`${user}/covers/${cover}`, bytes, { httpMetadata: { contentType: file.type } });
    return Response.json({ cover });
  } catch (error) {
    console.error('Cover upload failed', error);
    return Response.json({ error: 'Could not upload the picture. Please try again.' }, { status: 503 });
  }
}
