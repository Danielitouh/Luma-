import { env } from 'cloudflare:workers';
import { userId } from '@/db/storage';

export async function GET(request: Request, context: { params: Promise<{ cover: string }> }) {
  const user = userId(request);
  if (!user) return new Response(null, { status: 401 });
  const { cover } = await context.params;
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(cover))
    return new Response(null, { status: 404 });
  try {
    if (!env.BUCKET) throw new Error('Image storage unavailable');
    const object = await env.BUCKET.get(`${user}/covers/${cover}`);
    if (!object) return new Response(null, { status: 404 });
    const contentType = object.httpMetadata?.contentType;
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(contentType || ''))
      return new Response(null, { status: 404 });
    return new Response(object.body, { headers: { 'Content-Type': contentType!, 'Cache-Control': 'private, max-age=3600', 'X-Content-Type-Options': 'nosniff' } });
  } catch (error) {
    console.error('Cover load failed', error);
    return new Response(null, { status: 503 });
  }
}
